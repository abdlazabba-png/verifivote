# VerifiVote Logo & Icon Set

## Files
- `wordmark.svg` / `wordmark-1200.png` / `wordmark-600.png` — full logo with
  text, for documents, letterhead, presentations, and the dashboard header.
- `icons/icon.svg` — master vector icon (shield + checkmark), white
  background, rounded square. Use for favicons, app store listings, and
  anywhere a standard square icon is needed.
- `icons/icon-maskable.svg` — full-bleed version with extra padding, for
  Android adaptive/maskable icons (the OS applies its own circle/rounded/
  squircle mask on top, so content needs a safe margin — already built in).
- `icons/icon-{size}.png` — pre-rendered PNGs at standard PWA/app sizes
  (512, 192, 180, 152, 144, 128, 96, 72, 48, 32, 16).
- `icons/icon-maskable-{512,192}.png` — pre-rendered maskable PNGs.

## Add to your PWA manifest (`manifest.json` / `manifest.webmanifest`)

```json
{
  "name": "VerifiVote",
  "short_name": "VerifiVote",
  "icons": [
    { "src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
    { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" },
    { "src": "/icons/icon-maskable-192.png", "sizes": "192x192", "type": "image/png", "purpose": "maskable" },
    { "src": "/icons/icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ],
  "theme_color": "#1F3864",
  "background_color": "#FFFFFF",
  "display": "standalone"
}
```

## iOS home screen icon

Add to your HTML `<head>`:
```html
<link rel="apple-touch-icon" href="/icons/icon-180.png">
```

## Favicon

```html
<link rel="icon" type="image/png" sizes="32x32" href="/icons/icon-32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/icons/icon-16.png">
```

## Colors used
- Navy: `#1F3864` / gradient shield `#274A80` → `#152A4D`
- Gold: `#B08D57`
- These match the palette already used across your business documents,
  letterhead, and pitch materials.

## Notes
- All source files are SVG — fully editable/scalable, hand these to a
  designer or Claude Code as-is if any refinement is needed later.
- Verify the maskable icon actually looks right after Android installs it
  — simulators can render adaptive icon masking slightly differently from
  real devices, same caution as the PWA installability requirement already
  added to CLAUDE.md.
